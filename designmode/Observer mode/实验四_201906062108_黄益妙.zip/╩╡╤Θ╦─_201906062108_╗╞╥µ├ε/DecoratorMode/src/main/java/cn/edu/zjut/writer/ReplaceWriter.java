package cn.edu.zjut.writer;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @program: DecoratorMode
 * @description: ReplaceWriter
 * @author: hym(huangyimiao666 @ gmail.com)
 * @create: 2022-05-13 13:45
 **/
public class ReplaceWriter extends Writer{

    Writer out;

    /**
     * 敏感词列表
     */
    List<String> badWordList = new ArrayList<>();

    /**
    * @Description: 加载敏感词
    * @Param: [path]
    * @return: void
    * @Author: hym(huangyimiao666@gmail.com)
    * @Date: 22:02 2022/5/13
    */
    public void loadBadWords(String path) {
        try (Reader in = new FileReader(path)) {
            char[] buf = new char[4 * 1024];
            // 读取
            int len = in.read(buf);
            String s = String.valueOf(buf, 0, len);
            // 分割
            String[] words = s.split("[ ]+");
            // 敏感词加载到列表
            badWordList = new ArrayList<>(Arrays.asList(words));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
    * @Description: 包装writer
    * @Param: [out]
    * @return: 
    * @Author: hym(huangyimiao666@gmail.com)
    * @Date: 22:04 2022/5/13
    */
    public ReplaceWriter(Writer out) {
        this.out = out;
    }

    /**
    * @Description: 重写write方法,修改业务逻辑为写入文件前先屏蔽敏感词
    * @Param: [cbuf, off, len]
    * @return: void
    * @Author: hym(huangyimiao666@gmail.com)
    * @Date: 22:08 2022/5/13
    */
    @Override
    public void write(char[] cbuf, int off, int len) throws IOException {
        //对cbuf过滤
        this.doFilter(cbuf);
        //写入文件
        out.write(cbuf, off, len);
    }

    /**
    * @Description: 过滤敏感词
    * @Param: [cbuf]
    * @return: void
    * @Author: hym(huangyimiao666@gmail.com)
    * @Date: 22:05 2022/5/13
    */
    private void doFilter(char[] cbuf) {
        //转为string
        String s = String.valueOf(cbuf);
        for (String word : badWordList) {
            //匹配每个敏感词，用相同长度的*代替
            s = s.replaceAll(word, String.join("", Collections.nCopies(word.length(), "*")));
        }
        //将过滤后的string转为char数组
        s.getChars(0, s.length(), cbuf, 0);
    }


    @Override
    public void flush() throws IOException {
        out.flush();
    }

    @Override
    public void close() throws IOException {
        out.close();
    }
}
