package cn.edu.zjut.main;

import cn.edu.zjut.writer.ReplaceWriter;


import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
/**
 * @program: DecoratorMode
 * @description: main
 * @author: hym(huangyimiao666 @ gmail.com)
 * @create: 2022-05-13 13:48
 **/
public class Main{
    public static void main(String[] args) throws IOException{
        //原始句子
        String sentence = "im so sexy,i can become a porn star, fuck you!";
        //输出路径
        String outPath = "D:\\设计模式\\实验4\\Observer mode\\text.txt";
        //过滤词输入路径
        String badWordPath = "D:\\设计模式\\实验4\\Observer mode\\badword.txt";

        try (Writer out = new FileWriter(outPath);
             ReplaceWriter replaceOut = new ReplaceWriter(out);
        ) {
            //加载过滤词
            replaceOut.loadBadWords(badWordPath);
            //写入文本
            replaceOut.write(sentence);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
